package com.asm.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "courses")
public class Courses {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	public Long courseId;
	
	private Long catalogueId;
	public String courseName;
	public String courseDescription;
	public String courseOverview;
	
	
	
	public Long getCatalogueId() {
		return catalogueId;
	}
	public void setCatalogueId(Long catalogueId) {
		this.catalogueId = catalogueId;
	}
	public Long getCourseId() {
		return courseId;
	}
	public void setCourseId(Long courseId) {
		this.courseId = courseId;
	}

	public String getCourseName() {
		return courseName;
	}
	public void setCourseName(String courseName) {
		this.courseName = courseName;
	}
	public String getCourseDescription() {
		return courseDescription;
	}
	public void setCourseDescription(String courseDescription) {
		this.courseDescription = courseDescription;
	}
	public String getCourseOverview() {
		return courseOverview;
	}
	public void setCourseOverview(String courseOverview) {
		this.courseOverview = courseOverview;
	}
	@Override
	public String toString() {
		return "Courses [courseId=" + courseId + ", catalogueId=" + catalogueId + ", courseName=" + courseName
				+ ", courseDescription=" + courseDescription + ", courseOverview=" + courseOverview + "]";
	}
	
}
