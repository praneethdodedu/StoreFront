package com.asm.portal.repository;

import java.util.List;

import org.springframework.data.repository.CrudRepository;

import com.asm.model.UserCatalogue;

public interface IUserCatalogueRepository extends CrudRepository<UserCatalogue, Long> {

	public List<UserCatalogue> findByUserId(Long userId);
	
	public List<UserCatalogue> findDistinctCatalogueIdByUserId(Long userId);
//	public List<UserCatalogue> findByUserIdAndCatalogueId(Long userId,Long catalogueId);
}
