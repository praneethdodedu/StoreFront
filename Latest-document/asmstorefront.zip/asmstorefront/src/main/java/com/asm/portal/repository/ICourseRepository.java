package com.asm.portal.repository;

import java.util.List;

import org.springframework.data.repository.CrudRepository;

import com.asm.model.Courses;

public interface ICourseRepository extends CrudRepository< Courses, Long>{
	
	public Courses findByCourseId(Long courseId);
	
	public List<Courses> findByCatalogueId(Long catalogueId);

	
}
