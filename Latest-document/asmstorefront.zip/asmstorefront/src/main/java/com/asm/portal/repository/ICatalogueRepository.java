package com.asm.portal.repository;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;

import com.asm.model.Catalogue;

public interface ICatalogueRepository extends CrudRepository<Catalogue, Long> {

	public List<Catalogue> findAll();

	@Query("SELECT Distinct(c) FROM Catalogue c,UserCatalogue uc WHERE uc.catalogueId=c.catalogueId and uc.userId=:userId")
	public List<Catalogue> findUserCatalogues(@Param("userId") Long userId);

}
