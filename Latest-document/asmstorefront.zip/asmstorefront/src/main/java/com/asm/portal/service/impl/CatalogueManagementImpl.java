package com.asm.portal.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.asm.model.Catalogue;
import com.asm.model.Courses;
import com.asm.model.Modules;
import com.asm.model.UserCatalogue;
import com.asm.portal.repository.ICatalogueRepository;
import com.asm.portal.repository.ICourseRepository;
import com.asm.portal.repository.IModuleRepository;
import com.asm.portal.repository.IUserCatalogueRepository;
import com.asm.portal.service.ICatalogueManagement;

@Service
public class CatalogueManagementImpl implements ICatalogueManagement {

	@Autowired
	private ICatalogueRepository catalogueRepo;

	@Autowired
	private ICourseRepository courseRepo;

	@Autowired
	private IUserCatalogueRepository uCatalogueRepo;

	@Autowired
	private IModuleRepository uModuleRepo;

	@Override
	public List<Catalogue> findAllCatalogues() {
		return catalogueRepo.findAll();
	}

	@Override
	public List<UserCatalogue> findUserCourses(Long userId) {
		return uCatalogueRepo.findDistinctCatalogueIdByUserId(userId);
	}

	@Override
	public Courses findCoursesByCourseId(Long courseId) {
		// TODO Auto-generated method stub
		return courseRepo.findByCourseId(courseId);
	}

	@Override
	public List<Courses> findCoursesByCatalogueId(Long catalogueId) {
		// TODO Auto-generated method stub
		return courseRepo.findByCatalogueId(catalogueId);
	}

	@Override
	public List<Catalogue> findUserCatalogues(Long userId) {
		// TODO Auto-generated method stub
		return catalogueRepo.findUserCatalogues(userId);
	}

	@Override
	public List<Modules> findModulesbyCourseId(Long courseId) {
		// TODO Auto-generated method stub
		return uModuleRepo.findByCourseId(courseId);
	}

	@Override
	public Modules findMoudlebyModuleId(Long moduleId) {
		// TODO Auto-generated method stub
		return uModuleRepo.findByModuleId(moduleId);
	}

}
