package com.asm.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "modules")
public class Modules {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	public Long moduleId;
	public Long courseId;
	public String moduleName;
	public String moduleType;
	public String sequence;
	public String moduleDescription;
	
	public Long getModuleId() {
		return moduleId;
	}
	public void setModuleId(Long moduleId) {
		this.moduleId = moduleId;
	}
	public Long getCourseId() {
		return courseId;
	}
	public void setCourseId(Long courseId) {
		this.courseId = courseId;
	}
	public String getModuleName() {
		return moduleName;
	}
	public void setModuleName(String moduleName) {
		this.moduleName = moduleName;
	}
	public String getModuleType() {
		return moduleType;
	}
	public void setModuleType(String moduleType) {
		this.moduleType = moduleType;
	}
	public String getSequence() {
		return sequence;
	}
	public void setSequence(String sequence) {
		this.sequence = sequence;
	}
	public String getModuleDescription() {
		return moduleDescription;
	}
	public void setModuleDescription(String moduleDescription) {
		this.moduleDescription = moduleDescription;
	}
	@Override
	public String toString() {
		return "Modules [moduleId=" + moduleId + ", courseId=" + courseId + ", moduleName=" + moduleName
				+ ", moduleType=" + moduleType + ", sequence=" + sequence + ", moduleDescription=" + moduleDescription
				+ "]";
	}


	
}
