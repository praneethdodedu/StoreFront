package com.asm;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AsmstorefrontApplication {

	public static void main(String[] args) {
		SpringApplication.run(AsmstorefrontApplication.class, args);
	}
}
