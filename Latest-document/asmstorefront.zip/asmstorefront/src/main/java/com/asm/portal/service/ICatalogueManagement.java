package com.asm.portal.service;

import java.util.List;

import com.asm.model.Catalogue;
import com.asm.model.Courses;
import com.asm.model.Modules;
import com.asm.model.UserCatalogue;

public interface ICatalogueManagement {

	public List<Catalogue> findAllCatalogues();

	public List<Catalogue> findUserCatalogues(Long userId);

	public List<UserCatalogue> findUserCourses(Long userId);

	public List<Courses> findCoursesByCatalogueId(Long catalogueId);

	public Courses findCoursesByCourseId(Long courseId);

	public List<Modules> findModulesbyCourseId(Long courseId);

	public Modules findMoudlebyModuleId(Long moduleId);

}
