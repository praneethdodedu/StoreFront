package com.asm.portal.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.asm.model.Catalogue;
import com.asm.model.Courses;
import com.asm.model.Modules;
import com.asm.model.UserCatalogue;
import com.asm.portal.common.AsmException;
import com.asm.portal.service.ICatalogueManagement;

@RestController
@RequestMapping
public class CatalogueController {

	@Autowired
	private ICatalogueManagement catalogueManagement;

	/**
	 * This method will query and retrive all the catalogues available 
	 * @return List<Catalogue>
	 * @throws AsmException
	 */
	@GetMapping(value = "/catalogue")
	public @ResponseBody ResponseEntity<List<Catalogue>> getAllCatalogue() throws AsmException {

		try {
			return new ResponseEntity<List<Catalogue>>(catalogueManagement.findAllCatalogues(), HttpStatus.OK);
		} catch (Exception ex) {
			System.out.printf("exception");
			return null;
		}
	}

	/**
	 * This method will query and retrive all the catalogues available for a particular user
	 * @return List<Catalogue>
	 * @throws AsmException
	 */
	@GetMapping(value = "/catalogue/users/{userId}")
	public @ResponseBody ResponseEntity<List<Catalogue>> getUserCatalogue(@PathVariable Long userId) throws AsmException {

		try {
			return new ResponseEntity<List<Catalogue>>(catalogueManagement.findUserCatalogues(userId), HttpStatus.OK);
		} catch (Exception ex) {
			System.out.printf("exception");
			return null;
		}
	}

	/**
	 * This method will query and retrive all the courses available for a particular catalogue
	 * @return List<Courses>
	 * @throws AsmException
	 */
	@GetMapping(value = "/courses/catalogue/{catalogueId}")
	public @ResponseBody ResponseEntity<List<Courses>> getCoursesforCatagalogue(@PathVariable Long catalogueId) throws AsmException {

		try {
			return new ResponseEntity<List<Courses>>(catalogueManagement.findCoursesByCatalogueId(catalogueId), HttpStatus.OK);
		} catch (Exception ex) {
			System.out.printf("exception");
			return null;
		}
	}

	/**
	 * This method will return all the Courses and related catalogues for a specific user
	 * @param userId
	 * @return List<UserCatalogue>
	 * @throws AsmException
	 */
	@GetMapping(value = "/courses/user/{userId}")
	public @ResponseBody ResponseEntity<List<UserCatalogue>> getUserCourses(@PathVariable Long userId)
			throws AsmException {

		try {
			return new ResponseEntity<List<UserCatalogue>>(catalogueManagement.findUserCourses(userId),
					HttpStatus.OK);
		} catch (Exception ex) {
			System.out.printf("exception");
			return null;
		}
	}
	
	/**
	 * This method will returns the course details 
	 * @param courseId
	 * @return Courses
	 * @throws AsmException
	 */
	@GetMapping(value = "/courses/{courseId}")
	public @ResponseBody ResponseEntity<Courses> getCoursesDetails(@PathVariable Long courseId)
			throws AsmException {

		try {
			return new ResponseEntity<Courses>(catalogueManagement.findCoursesByCourseId(courseId),
					HttpStatus.OK);
		} catch (Exception ex) {
			System.out.printf("exception");
			return null;
		}
	}
	
	
	/**
	 * This method will returns the Module details for a give course
	 * @param courseId
	 * @return List<Modules>
	 * @throws AsmException
	 */
	@GetMapping(value = "/modules/course/{courseId}")
	public @ResponseBody ResponseEntity<List<Modules>> getModuleforCourse(@PathVariable Long courseId)
			throws AsmException {

		try {
			return new ResponseEntity<List<Modules>>(catalogueManagement.findModulesbyCourseId(courseId),
					HttpStatus.OK);
		} catch (Exception ex) {
			System.out.printf("exception");
			return null;
		}
	}
	
	
	/**
	 * This method will returns the Module details for a given module
	 * @param moduleId
	 * @return Modules
	 * @throws AsmException
	 */
	@GetMapping(value = "/modules/{moduleId}")
	public @ResponseBody ResponseEntity<Modules> getModuleDetails(@PathVariable Long moduleId)
			throws AsmException {

		try {
			return new ResponseEntity<Modules>(catalogueManagement.findMoudlebyModuleId(moduleId),
					HttpStatus.OK);
		} catch (Exception ex) {
			System.out.printf("exception");
			return null;
		}
	}
}
