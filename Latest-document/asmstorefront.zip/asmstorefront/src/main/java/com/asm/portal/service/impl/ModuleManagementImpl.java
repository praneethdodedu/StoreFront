package com.asm.portal.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.asm.model.Modules;
import com.asm.portal.repository.IModuleRepository;
import com.asm.portal.service.IModuleManagement;

public class ModuleManagementImpl implements IModuleManagement {

	@Autowired
	private IModuleRepository moduleRepo;

	@Override
	public List<Modules> findModulesByCourseId(Long courseId) {

		return moduleRepo.findByCourseId(courseId);

	}

	@Override
	public Modules findModuleByModuleId(Long moduleId) {

		return moduleRepo.findByModuleId(moduleId);

	}

}
