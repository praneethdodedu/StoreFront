package com.asm.portal.common;

public class AsmException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 8579744067867928532L;
	
		public AsmException() {
	        super();
	    }

	    public AsmException(String message) {
	        super(message);
	    }

}
