package com.asm.portal.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.asm.model.Courses;
import com.asm.portal.repository.ICourseRepository;
import com.asm.portal.service.ICourseManagement;

@Service
public class CourseManagementImpl implements ICourseManagement {
	
	@Autowired
	private ICourseRepository courseRepo;
	
/*	@Override
	public List<Courses> findCoursesByCatalogueId(Long catalogueId){
				return courseRepo.findByCatalogueId(catalogueId);
	}
*/
	@Override
	public Courses findCourseByCourseId(Long courseId) {
		// TODO Auto-generated method stub
		return courseRepo.findByCourseId(courseId);
	}

	@Override
	public List<Courses> findCoursesByCatalogueId(Long catalogueId) {
		// TODO Auto-generated method stub
		return null;
	}
	

	
}
