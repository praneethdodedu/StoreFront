package com.asm.portal.service;

import java.util.List;

import com.asm.model.Courses;

public interface ICourseManagement {

	public List<Courses> findCoursesByCatalogueId(Long catalogueId);

	public Courses findCourseByCourseId(Long courseId);

}
