package com.asm.portal.repository;

import java.util.List;

import org.springframework.data.repository.CrudRepository;

import com.asm.model.Modules;

public interface IModuleRepository extends CrudRepository<Modules, Long> {

	public List<Modules> findByCourseId(Long courseId);

	public Modules findByModuleId(Long moduleId);

}
