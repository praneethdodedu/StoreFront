package com.asm.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "catalogue")
public class Catalogue {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	public Long catalogueId;
	public String 	name;
	public String description;

	public Long getCatalogueId() {
		return catalogueId;
	}
	public void setCatalogueId(Long catalogueId) {
		this.catalogueId = catalogueId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	@Override
	public String toString() {
		return "Catalogue [catalogueId=" + catalogueId + ", name=" + name + ", description=" + description + "]";
	}

}
