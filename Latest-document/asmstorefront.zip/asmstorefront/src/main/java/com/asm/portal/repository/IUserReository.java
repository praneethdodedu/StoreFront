package com.asm.portal.repository;

import org.springframework.data.repository.CrudRepository;

import com.asm.model.Users;

public interface IUserReository extends CrudRepository<Users, Long> {

	public Users findByUserName(String userName);
	public Users findByUserNameAndPassword(String userName,String password);

}
