package com.asm.portal.service;

import java.util.List;

import com.asm.model.Modules;

public interface IModuleManagement {


	public List<Modules> findModulesByCourseId(Long courseId);

	public Modules findModuleByModuleId(Long moduleId);
}
