package com.asm.portal.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.asm.model.Users;
import com.asm.portal.common.AsmException;
import com.asm.portal.repository.IUserReository;

@RestController
@RequestMapping(value = "/authenticate")
public class AuthController {

	@Autowired
	private IUserReository userRepo;
	
	
	 /**
	  * GetAllJobs returns true on authentication success else returns false
	 * @return 
	 * @return 
	  **/
	@PostMapping
	public ResponseEntity<Boolean> getAllJobs(@RequestParam String userName, @RequestParam String password) throws AsmException {

		Users authUser = null;
		try {
			System.out.println(" received user " + userName);
			authUser = userRepo.findByUserName(userName);
			if (authUser != null) {
				return new ResponseEntity<Boolean>(true,HttpStatus.OK);
			}
			return new ResponseEntity<Boolean>(false,HttpStatus.OK);
		} catch (Exception ex) {
			System.out.printf("exception");
			 return null;
		}
	}

    @RequestMapping(value = "/login")
    public String login() {
        return "index";
    }

}
