package com.adobe.asm.service;

import com.adobe.asm.constant.model.UserProfile;
import com.adobe.asm.exceptions.ApplicationException;
import com.adobe.asm.model.LoginResponse;
@FunctionalInterface
public interface ISamlAssertService {
	
	public String buildSAMLAssertion(UserProfile userProfile,LoginResponse loginResp) throws ApplicationException;

}
