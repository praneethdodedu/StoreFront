package com.adobe.asm.util;

import java.io.FileInputStream;
import java.security.KeyStore;
import java.security.PrivateKey;
import java.security.cert.X509Certificate;

import org.opensaml.Configuration;
import org.opensaml.DefaultBootstrap;
import org.opensaml.xml.security.SecurityConfiguration;
import org.opensaml.xml.security.SecurityHelper;
import org.opensaml.xml.security.credential.Credential;
import org.opensaml.xml.security.x509.BasicX509Credential;
import org.opensaml.xml.signature.Signature;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.adobe.asm.exceptions.ApplicationException;

@Component
public class SignAssertion {
	private static final Logger logger = LoggerFactory.getLogger(SignAssertion.class);
	static final String CERTIFICATEALIASNAME = "selfsigned";
	static final String FILENAME = "./src/main/resources/keystore/keystore.jks";

	private static final String PASSWORD = "password";

	private Credential intializeCredentials() throws ApplicationException {
		try {

			char[] passwordChar = PASSWORD.toCharArray();

			KeyStore ks = KeyStore.getInstance(KeyStore.getDefaultType());
			FileInputStream fis = new FileInputStream(FILENAME);

			ks.load(fis, passwordChar);

			fis.close();

			KeyStore.PrivateKeyEntry pkEntry = (KeyStore.PrivateKeyEntry) ks.getEntry(
					SignAssertion.CERTIFICATEALIASNAME, new KeyStore.PasswordProtection(PASSWORD.toCharArray()));
			PrivateKey pk = pkEntry.getPrivateKey();

			X509Certificate certificate = (X509Certificate) pkEntry.getCertificate();
			BasicX509Credential credential = new BasicX509Credential();
			credential.setEntityCertificate(certificate);
			credential.setPrivateKey(pk);
			return credential;
		} catch (Exception e) {
			logger.error("error in constructing SAML Credential {}", e);
			throw new ApplicationException("error in constructing SAML Credential : " + e.getMessage());
		}
	}

	public Signature getSamlSignature() throws ApplicationException {
		try {
			Credential signingCredential = this.intializeCredentials();
			DefaultBootstrap.bootstrap();
			Signature signature = (Signature) Configuration.getBuilderFactory()
					.getBuilder(Signature.DEFAULT_ELEMENT_NAME).buildObject(Signature.DEFAULT_ELEMENT_NAME);

			signature.setSigningCredential(signingCredential);

			SecurityConfiguration secConfig = Configuration.getGlobalSecurityConfiguration();
			SecurityHelper.prepareSignatureParams(signature, signingCredential, secConfig, null);
			return signature;
		} catch (Exception e) {
			logger.error("error in constructing SAML Signature {}", e);
			throw new ApplicationException("error in constructing SAML Signature : " + e.getMessage());
		}
	}
}
