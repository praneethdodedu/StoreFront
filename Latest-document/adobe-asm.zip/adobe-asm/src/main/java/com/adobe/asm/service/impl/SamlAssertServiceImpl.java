package com.adobe.asm.service.impl;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.UUID;

import org.joda.time.DateTime;
import org.joda.time.DateTimeZone;
import org.opensaml.Configuration;
import org.opensaml.DefaultBootstrap;
import org.opensaml.common.SAMLObjectBuilder;
import org.opensaml.common.SAMLVersion;
import org.opensaml.saml2.core.Assertion;
import org.opensaml.saml2.core.Attribute;
import org.opensaml.saml2.core.AttributeStatement;
import org.opensaml.saml2.core.AttributeValue;
import org.opensaml.saml2.core.Audience;
import org.opensaml.saml2.core.AudienceRestriction;
import org.opensaml.saml2.core.AuthnContext;
import org.opensaml.saml2.core.AuthnContextClassRef;
import org.opensaml.saml2.core.AuthnStatement;
import org.opensaml.saml2.core.Condition;
import org.opensaml.saml2.core.Conditions;
import org.opensaml.saml2.core.Issuer;
import org.opensaml.saml2.core.NameID;
import org.opensaml.saml2.core.OneTimeUse;
import org.opensaml.saml2.core.Response;
import org.opensaml.saml2.core.Status;
import org.opensaml.saml2.core.StatusCode;
import org.opensaml.saml2.core.Subject;
import org.opensaml.saml2.core.SubjectConfirmation;
import org.opensaml.saml2.core.SubjectConfirmationData;
import org.opensaml.saml2.core.impl.AudienceBuilder;
import org.opensaml.saml2.core.impl.AudienceRestrictionBuilder;
import org.opensaml.saml2.core.impl.ResponseMarshaller;
import org.opensaml.xml.ConfigurationException;
import org.opensaml.xml.XMLObjectBuilder;
import org.opensaml.xml.XMLObjectBuilderFactory;
import org.opensaml.xml.schema.XSString;
import org.opensaml.xml.util.XMLHelper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.w3c.dom.Element;

import com.adobe.asm.constant.model.UserProfile;
import com.adobe.asm.exceptions.ApplicationException;
import com.adobe.asm.model.LoginResponse;
import com.adobe.asm.service.ISamlAssertService;
import com.adobe.asm.util.ApplicationConstants;
import com.adobe.asm.util.SignAssertion;

@Service
public class SamlAssertServiceImpl implements ISamlAssertService {

	private static Logger log = LoggerFactory.getLogger(SamlAssertServiceImpl.class);

	private static XMLObjectBuilderFactory builderFactory;

	@Value("${sn.url}")
	private String schoolNetURL;
	
	@Value("${com.pearson.k12rs.app.redirect}")
	private String destination;
	
	@Autowired
	private SignAssertion signAssertion;

	
	private Map<String,String> buildAttributes(UserProfile userProfile){
		
		Map<String,String> customAttributes = new HashMap<>();
		customAttributes.put("user_id", userProfile.getData().getCurrentUser().getId());
		customAttributes.put("first_name", userProfile.getData().getCurrentUser().getName().getFirstName());
		customAttributes.put("last_name", userProfile.getData().getCurrentUser().getName().getLastName());
		customAttributes.put("org_id",userProfile.getData().getCurrentUser().getDefaultInstitution().getInstitutionId());
		customAttributes.put("org_name",userProfile.getData().getCurrentUser().getDefaultInstitution().getInstitutionName());		
		return customAttributes;
	}
	
	/**
	 * Builds a SAML Attribute of type String
	 * @param name
	 * @param value
	 * @param builderFactory
	 * @return
	 * @throws ConfigurationException
	 */
	public static Attribute buildStringAttribute(String name, String value) throws ConfigurationException
	{
		SAMLObjectBuilder<?> attrBuilder = (SAMLObjectBuilder<?>) getSAMLBuilder().getBuilder(Attribute.DEFAULT_ELEMENT_NAME);
		 Attribute attrFirstName = (Attribute) attrBuilder.buildObject();
		 attrFirstName.setName(name);
 
		 // Set custom Attributes
		 XMLObjectBuilder<?> stringBuilder = getSAMLBuilder().getBuilder(XSString.TYPE_NAME);
		 XSString attrValueFirstName = (XSString) stringBuilder.buildObject(AttributeValue.DEFAULT_ELEMENT_NAME, XSString.TYPE_NAME);
		 attrValueFirstName.setValue(value);
 
		 attrFirstName.getAttributeValues().add(attrValueFirstName);
		return attrFirstName;
	}
	
	@Override
	public String buildSAMLAssertion(UserProfile userProfile, LoginResponse loginResp) throws ApplicationException {
		try {
			
			String requestId = UUID.randomUUID().toString();
			
			// Create the NameIdentifier
			SAMLObjectBuilder<?> nameIdBuilder = (SAMLObjectBuilder<?>) getSAMLBuilder()
					.getBuilder(NameID.DEFAULT_ELEMENT_NAME);
			NameID nameId = (NameID) nameIdBuilder.buildObject();
			nameId.setValue(userProfile.getData().getCurrentUser().getId());
			nameId.setNameQualifier(userProfile.getData().getCurrentUser().getName().getFirstName());
			nameId.setFormat(NameID.UNSPECIFIED);

			// Create the SubjectConfirmation

			SAMLObjectBuilder<?> confirmationMethodBuilder = (SAMLObjectBuilder<?>) getSAMLBuilder()
					.getBuilder(SubjectConfirmationData.DEFAULT_ELEMENT_NAME);
			SubjectConfirmationData confirmationMethod = (SubjectConfirmationData) confirmationMethodBuilder
					.buildObject();
			DateTime now = new DateTime(DateTimeZone.UTC);
			confirmationMethod.setNotBefore(now);
			confirmationMethod.setNotOnOrAfter(now.plusMinutes(loginResp.getExpiresIn()));
			confirmationMethod.setInResponseTo(userProfile.getRequestId());
			confirmationMethod.setRecipient(destination); // Need to decide the value for this field

			SAMLObjectBuilder<?> subjectConfirmationBuilder = (SAMLObjectBuilder<?>) getSAMLBuilder()
					.getBuilder(SubjectConfirmation.DEFAULT_ELEMENT_NAME);
			SubjectConfirmation subjectConfirmation = (SubjectConfirmation) subjectConfirmationBuilder.buildObject();
			subjectConfirmation.setMethod(SubjectConfirmation.METHOD_BEARER);
			subjectConfirmation.setSubjectConfirmationData(confirmationMethod);

			// Create the Subject
			SAMLObjectBuilder<?> subjectBuilder = (SAMLObjectBuilder<?>) getSAMLBuilder()
					.getBuilder(Subject.DEFAULT_ELEMENT_NAME);
			Subject subject = (Subject) subjectBuilder.buildObject();

			subject.setNameID(nameId);
			subject.getSubjectConfirmations().add(subjectConfirmation);

			// Create Authentication Statement
			SAMLObjectBuilder<?> authStatementBuilder = (SAMLObjectBuilder<?>) getSAMLBuilder()
					.getBuilder(AuthnStatement.DEFAULT_ELEMENT_NAME);
			AuthnStatement authnStatement = (AuthnStatement) authStatementBuilder.buildObject();
			DateTime now2 = new DateTime();
			authnStatement.setAuthnInstant(now2);
			authnStatement.setSessionIndex(loginResp.getAccessToken());
			authnStatement.setSessionNotOnOrAfter(now2.plus(loginResp.getExpiresIn()));

			SAMLObjectBuilder<?> authContextBuilder = (SAMLObjectBuilder<?>) getSAMLBuilder()
					.getBuilder(AuthnContext.DEFAULT_ELEMENT_NAME);
			AuthnContext authnContext = (AuthnContext) authContextBuilder.buildObject();
			
			

			SAMLObjectBuilder<?> authContextClassRefBuilder = (SAMLObjectBuilder<?>) getSAMLBuilder()
					.getBuilder(AuthnContextClassRef.DEFAULT_ELEMENT_NAME);
			AuthnContextClassRef authnContextClassRef = (AuthnContextClassRef) authContextClassRefBuilder.buildObject();
			authnContextClassRef.setAuthnContextClassRef("urn:oasis:names:tc:SAML:2.0:ac:classes:PasswordProtectedTransport");

			authnContext.setAuthnContextClassRef(authnContextClassRef);
			authnStatement.setAuthnContext(authnContext);

			// Builder Attributes
			SAMLObjectBuilder<?> attrStatementBuilder = (SAMLObjectBuilder<?>) getSAMLBuilder()
					.getBuilder(AttributeStatement.DEFAULT_ELEMENT_NAME);
			AttributeStatement attrStatement = (AttributeStatement) attrStatementBuilder.buildObject();

			Map<String,String> attributes = this.buildAttributes(userProfile);
			
			attributes.put("refresh_token", loginResp.getRefreshToken());
			if(attributes != null){
			Iterator<String> keySet = attributes.keySet().iterator();
			while (keySet.hasNext())
			{
			String key = keySet.next();
			String val = attributes.get(key);
			Attribute attrFirstName = buildStringAttribute(key, val);
			attrStatement.getAttributes().add(attrFirstName);
			}
			}
			
			// Create the do-not-cache condition
			SAMLObjectBuilder<?> doNotCacheConditionBuilder = (SAMLObjectBuilder<?>) getSAMLBuilder()
					.getBuilder(OneTimeUse.DEFAULT_ELEMENT_NAME);
			Condition condition = (Condition) doNotCacheConditionBuilder.buildObject();

			SAMLObjectBuilder<?> conditionsBuilder = (SAMLObjectBuilder<?>) getSAMLBuilder()
					.getBuilder(Conditions.DEFAULT_ELEMENT_NAME);
			Conditions conditions = (Conditions) conditionsBuilder.buildObject();
			
			AudienceRestriction audienceRestriction = new AudienceRestrictionBuilder().buildObject();
		    Audience issuerAudience = new AudienceBuilder().buildObject();
		    issuerAudience.setAudienceURI(ApplicationConstants.AUDIENCE); // Need to decide
		    audienceRestriction.getAudiences().add(issuerAudience);
		    
		    
			conditions.setNotBefore(now);
		    conditions.setNotOnOrAfter(now.plusMillis(loginResp.getExpiresIn()));
		    conditions.getAudienceRestrictions().add(audienceRestriction);
			
			conditions.getConditions().add(condition);

			// Create Issuer
			SAMLObjectBuilder<?> issuerBuilder = (SAMLObjectBuilder<?>) getSAMLBuilder()
					.getBuilder(Issuer.DEFAULT_ELEMENT_NAME);
			Issuer issuer = (Issuer) issuerBuilder.buildObject();
			issuer.setValue(schoolNetURL); // "Temporary"  For now setting the issuer value to school net instance , this should be replaced with dynamic end point instance
 
			// Create the assertion
			SAMLObjectBuilder<?> assertionBuilder = (SAMLObjectBuilder<?>) getSAMLBuilder()
					.getBuilder(Assertion.DEFAULT_ELEMENT_NAME);
			Assertion assertion = (Assertion) assertionBuilder.buildObject();
			assertion.setIssuer(issuer);
			assertion.setID(userProfile.getRequestId()); // "Temporary" For now setting to request id which is unique to every user profile pull request
			assertion.setIssueInstant(now);
			assertion.setVersion(SAMLVersion.VERSION_20);
			assertion.setSubject(subject);
			assertion.getAuthnStatements().add(authnStatement);
			assertion.getAttributeStatements().add(attrStatement);
			assertion.setConditions(conditions);
			// Create Status
			SAMLObjectBuilder<?> statusBuilder = (SAMLObjectBuilder<?>) getSAMLBuilder()
					.getBuilder(Status.DEFAULT_ELEMENT_NAME);
			Status status = (Status) statusBuilder.buildObject();
			// Create Status Code
						SAMLObjectBuilder<?> statusCodeBuilder = (SAMLObjectBuilder<?>) getSAMLBuilder()
								.getBuilder(StatusCode.DEFAULT_ELEMENT_NAME);
			StatusCode statusCode = (StatusCode) statusCodeBuilder.buildObject();
			statusCode.setValue(StatusCode.SUCCESS_URI);
			status.setStatusCode(statusCode);
			SAMLObjectBuilder<?> responseBuilder = (SAMLObjectBuilder<?>) getSAMLBuilder()
					.getBuilder(Response.DEFAULT_ELEMENT_NAME);
			Response response = (Response) responseBuilder.buildObject();
			response.getAssertions().add(assertion);
			response.setStatus(status);
			response.setDestination(destination);
			response.setID(requestId);
			response.setInResponseTo(userProfile.getRequestId());
			response.setIssueInstant(now);
			
			// Create Issuer
						SAMLObjectBuilder<?> issuerBuilder1 = (SAMLObjectBuilder<?>) getSAMLBuilder()
								.getBuilder(Issuer.DEFAULT_ELEMENT_NAME);
						Issuer issuer1 = (Issuer) issuerBuilder1.buildObject();
						issuer1.setValue(schoolNetURL); // "Temporary"  For now setting the issuer value to school net instance , this should be replaced with dynamic end point instance
			 
			response.setIssuer(issuer1);
		//	response.setSignature(signAssertion.getSamlSignature());
			ResponseMarshaller respMarshaller = new ResponseMarshaller();
			Element plaintextElement = respMarshaller.marshall(response);
			String originalAssertionString = XMLHelper.nodeToString(plaintextElement);
			
			/**
			AssertionMarshaller marshaller = new AssertionMarshaller();
			Element plaintextElement = marshaller.marshall(assertion);
			String originalAssertionString = XMLHelper.nodeToString(plaintextElement);**/

			log.info("Saml Assertion {} ",originalAssertionString);
			return originalAssertionString;
		} catch (Exception e) {
			log.error("Error in building saml assertion  {}",e);
			throw new ApplicationException("Error in building saml assertion  : "+e.getMessage());
		}
	}
	 
	public static XMLObjectBuilderFactory getSAMLBuilder() throws ConfigurationException{
 
		if(builderFactory == null){
			// OpenSAML 2.3
			 DefaultBootstrap.bootstrap();
	         builderFactory = Configuration.getBuilderFactory();
		}
 
		return builderFactory;
	}

}
