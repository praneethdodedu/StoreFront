package com.adobe.asm.service.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import org.apache.commons.lang3.StringUtils;
import org.apache.http.NameValuePair;
import org.apache.http.message.BasicNameValuePair;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import com.adobe.asm.exceptions.ApplicationException;
import com.adobe.asm.model.LoginResponse;
import com.adobe.asm.service.IAuthService;
import com.adobe.asm.util.ApplicationConstants;
import com.adobe.asm.util.HTTPClientUtil;
import com.adobe.asm.util.ObjectJSONMapper;

@Service
public class AuthServiceImpl implements IAuthService {

	private static Logger log = LoggerFactory.getLogger(AuthServiceImpl.class);

	@Value("${sn.url}")
	private String schoolNetURL;

	@Value("${sn.client.id}")
	private String clientId;

	@Value("${sn.client.secret}")
	private String clientSecret;

	@Value("${sn.sessionUrl}")
	private String sessionUrl;

	@Autowired
	private HTTPClientUtil httpClientUtil;

	@Autowired
	private ObjectJSONMapper mapper;

	@Autowired
	private BCryptPasswordEncoder passwordEncoder;

	@Override
	public LoginResponse authenticateUser(String userName, String password) throws ApplicationException {

		String corelationId = UUID.randomUUID().toString();
		List<NameValuePair> urlParameters = new ArrayList<>();

		urlParameters.add(new BasicNameValuePair("username", userName));
		urlParameters.add(new BasicNameValuePair("password", password));
		urlParameters.add(new BasicNameValuePair("client_id", clientId));
		urlParameters.add(new BasicNameValuePair("client_secret", clientSecret));
		urlParameters.add(new BasicNameValuePair("grant_type", "password"));

		Map<String, String> reqHeaders = new HashMap<>();
		reqHeaders.put(ApplicationConstants.CONTENT_TYPE_KEY, "application/x-www-form-urlencoded");
		reqHeaders.put("corelation-id", corelationId);

		String loginResponse = httpClientUtil.executePostRequest(schoolNetURL, reqHeaders, urlParameters);
		if (StringUtils.isBlank(loginResponse)) {
			throw new ApplicationException("");
		}
		log.info(" Http Resonse: {} ",loginResponse);
		LoginResponse loginUser = null;
		try {
			loginUser = (LoginResponse) mapper.fromJson(loginResponse, LoginResponse.class);
		} catch (Exception e) {
			log.error("Error in formation the user response: {}",e);
			throw new ApplicationException("");
		}
		log.info("LoginResponse: {} ",loginUser);

		return loginUser;
	}

	@Override
	public LoginResponse refreshToken(String refreshToken) throws ApplicationException {

		String corelationId = UUID.randomUUID().toString();
		List<NameValuePair> urlParameters = new ArrayList<>();
		urlParameters.add(new BasicNameValuePair("refresh_token", refreshToken));
		urlParameters.add(new BasicNameValuePair("client_id", clientId));
		urlParameters.add(new BasicNameValuePair("client_secret", clientSecret));
		urlParameters.add(new BasicNameValuePair("grant_type", "refresh_token"));

		Map<String, String> reqHeaders = new HashMap<>();
		reqHeaders.put(ApplicationConstants.CONTENT_TYPE_KEY, "application/x-www-form-urlencoded");
		reqHeaders.put("corelation-id", corelationId);

		String response = httpClientUtil.executePostRequest(schoolNetURL, reqHeaders, urlParameters);
		if(StringUtils.isNotBlank(response)){
			LoginResponse loginUser = null;
			try {
				loginUser = (LoginResponse) mapper.fromJson(response, LoginResponse.class);
				return loginUser;
			} catch (Exception e) {
				log.error("Error in parsing refresh token {}",e);
				throw new ApplicationException("Error in parsing refresh token : "+e.getMessage());
			} 
		}
		return null;
	}

	@Override
	public String validateSession(String accessToken) throws ApplicationException {
		Map<String, String> reqHeaders = new HashMap<>();
		reqHeaders.put(ApplicationConstants.CONTENT_TYPE_KEY, "application/json");
		reqHeaders.put("Authorization", "bearer " + accessToken);
		return httpClientUtil.executeGetRequest(sessionUrl, reqHeaders);
	}
}
