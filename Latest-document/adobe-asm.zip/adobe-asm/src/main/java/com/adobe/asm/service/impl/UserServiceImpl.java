package com.adobe.asm.service.impl;

import java.io.IOException;
import java.net.URISyntaxException;
import java.net.URL;
import java.util.HashMap;
import java.util.Map;

import org.apache.http.client.utils.URIBuilder;
import org.json.JSONArray;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.adobe.asm.constant.model.UserProfile;
import com.adobe.asm.exceptions.ApplicationException;
import com.adobe.asm.model.LoginResponse;
import com.adobe.asm.service.IUserService;
import com.adobe.asm.util.HTTPClientUtil;
import com.adobe.asm.util.ObjectJSONMapper;

@Service
public class UserServiceImpl implements IUserService {

	private static Logger log = LoggerFactory.getLogger(UserServiceImpl.class);

	@Value("${sn.instance}")
	private String schoolNetInstance;

	@Value("${sn.district.search.url}")
	private String districtSearch;

	@Value("${psc.user.profile.url}")
	private String userProfileURL;

	@Autowired
	private HTTPClientUtil httpClientUtil;

	@Autowired
	private ObjectJSONMapper mapper;

	@Override
	public UserProfile getUerProfile(LoginResponse loginResponse) throws ApplicationException {

		UserProfile userProfile = null;
		URIBuilder b = null;

		Map<String, String> reqHeaders = new HashMap<>();
		reqHeaders.put("content-type", "application/json");
		try {
			b = new URIBuilder(userProfileURL);
			b.addParameter("instance", schoolNetInstance);
			b.addParameter("token", loginResponse.getAccessToken());
			URL url = b.build().toURL();
			String userProfileResp = httpClientUtil.executeGetRequest(url.toString(), reqHeaders);
			log.info("loginUser Response: {}", userProfileResp);
			userProfile = (UserProfile) mapper.fromJson(userProfileResp, UserProfile.class);

			log.info("loginUser Response: {}", userProfile);

			return userProfile;
		} catch (Exception e) {
			log.error("Error in retrieving user profile info : {}", e);
			throw new ApplicationException("Error in retrieving user profile " + e);
		}

	}

	@Override
	public String getDistrictDetails(String searchParam) throws ApplicationException {

		URIBuilder b = null;

		Map<String, String> reqHeaders = new HashMap<>();
		reqHeaders.put("content-type", "application/json");
		try {
			b = new URIBuilder(districtSearch);
			b.addParameter("query", searchParam);
			URL url = b.build().toURL();
			String districtResp = httpClientUtil.executeGetRequest(url.toString(), reqHeaders);
			log.info(districtResp);

			JSONObject details = new JSONObject(districtResp);
			JSONArray userDetJson = details.getJSONArray("solrResponses");

			return userDetJson.toString();
		} catch (URISyntaxException | IOException e) {
			log.error("Error in retrieving District info : {}", e);
			throw new ApplicationException("Error in retrieving District details " + e);
		}

	}

}
