package com.adobe.asm.service;

import com.adobe.asm.constant.model.UserProfile;
import com.adobe.asm.exceptions.ApplicationException;
import com.adobe.asm.model.LoginResponse;

public interface IUserService {

	public UserProfile getUerProfile(LoginResponse loginResponse) throws ApplicationException;

	public String getDistrictDetails(String searchParam) throws ApplicationException;
}
