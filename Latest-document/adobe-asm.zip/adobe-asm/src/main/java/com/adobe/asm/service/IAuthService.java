package com.adobe.asm.service;

import com.adobe.asm.exceptions.ApplicationException;
import com.adobe.asm.model.LoginResponse;

public interface IAuthService {

	public LoginResponse authenticateUser(String userName, String password) throws ApplicationException;
	
	public LoginResponse refreshToken(String refreshToken)
			throws ApplicationException;

	public String validateSession(String accessToken) throws ApplicationException;
}
