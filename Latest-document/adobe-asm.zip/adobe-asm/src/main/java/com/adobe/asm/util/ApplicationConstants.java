package com.adobe.asm.util;

public final class ApplicationConstants {

	public static final String LOGIN_PAGE = "login";
	public static final String ERROR_MESSAGE = "errorMsg";
	public static final String LOGIN_FAILED_ERR_MSG = "Username or password is incorrect. Please try again.";
	public static final String CONTENT_TYPE_KEY = "content-type";
	public static final String CONTENT_TYPE_VALUE_URI_ENCODED = "application/x-www-form-urlencoded";

	public static final String CONTENT_TYPE_VALUE_APP_JSON = "application/json";
	
	public static final String CHAR_ENCODING = "UTF-8";
	
	public static final String HTTPS ="https";
	public static final String HTTP ="http";
	public static final String AUDIENCE="K12RS App";
	private ApplicationConstants() {

	}

}
