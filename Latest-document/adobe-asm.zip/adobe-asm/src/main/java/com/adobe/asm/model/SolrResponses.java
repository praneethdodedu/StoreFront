package com.adobe.asm.model;

import org.codehaus.jackson.annotate.JsonProperty;
import org.codehaus.jackson.map.annotate.JsonSerialize;

@JsonSerialize(include=JsonSerialize.Inclusion.NON_NULL)
public class SolrResponses {


	@JsonProperty("orgName")
	private String orgName;


	@JsonProperty("externalidpid")
	private String externalidpid;

	@JsonProperty("authURL")
	private String authURL;
	

	@JsonProperty("metaDataURL")
	private String metaDataURL;

	public String getOrgName() {
		return orgName;
	}

	public void setOrgName(String orgName) {
		this.orgName = orgName;
	}

	public String getExternalidpid() {
		return externalidpid;
	}

	public void setExternalidpid(String externalidpid) {
		this.externalidpid = externalidpid;
	}

	public String getAuthURL() {
		return authURL;
	}

	public void setAuthURL(String authURL) {
		this.authURL = authURL;
	}

	public String getMetaDataURL() {
		return metaDataURL;
	}

	public void setMetaDataURL(String metaDataURL) {
		this.metaDataURL = metaDataURL;
	}

	@Override
	public String toString() {
		return "SolrResponses [orgName=" + orgName + ", externalidpid=" + externalidpid + ", authURL=" + authURL
				+ ", metaDataURL=" + metaDataURL + "]";
	}

	
	
}
