/**
 * 
 */
package com.adobe.asm.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * @author Ramsudheer.Palnati
 *
 */
//@Entity
//@Table(name = "psoc_config")
public class PSOCConfig extends LoginResponse{

	//@Column(name="corelation_id")
	private String corelationId;

	//@Id
	//@Column(name="user_name")
	private String userName;
	
	//@Column(name="password")
	private String password;
	
	public String getCorelationId() {
		return corelationId;
	}

	public void setCorelationId(String corelationId) {
		this.corelationId = corelationId;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}


}
