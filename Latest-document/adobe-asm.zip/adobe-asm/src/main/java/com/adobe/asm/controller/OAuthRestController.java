package com.adobe.asm.controller;

import javax.servlet.http.HttpServletRequest;

import org.joda.time.DateTime;
import org.joda.time.DateTimeZone;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.adobe.asm.constant.model.UserProfile;
import com.adobe.asm.exceptions.ApplicationException;
import com.adobe.asm.model.LoginResponse;
import com.adobe.asm.service.impl.AuthServiceImpl;
import com.adobe.asm.service.impl.UserServiceImpl;

@RestController
public class OAuthRestController {

	private static Logger log = LoggerFactory.getLogger(OAuthRestController.class);

	@Autowired
	private AuthServiceImpl authService;

	@Autowired
	private UserServiceImpl userService;

	@RequestMapping(value = "/refreshtoken", method = RequestMethod.POST)
	public String refreshAccessToken(@RequestParam("refreshtoken") String refreshtoken, HttpServletRequest request)
			throws ApplicationException {

		UserProfile userProfile;

		/*
		 * Step1: Get the Access token and refresh token
		 */
		LoginResponse loginUser = authService.refreshToken(refreshtoken);
		
		if (loginUser == null) {
			throw new ApplicationException("");
		}
		/*
		 * Step2: Get User profile by using access token
		 */
		userProfile = userService.getUerProfile(loginUser);
		if (userProfile == null) {
			throw new ApplicationException("");
		}

		log.info("userProfile: {}", userProfile);

		JSONObject jObject = new JSONObject();

		jObject.put("accessToken", loginUser.getAccessToken());
		jObject.put("tokenType", loginUser.getTokenType());
		jObject.put("expiresIn", "" + new DateTime(DateTimeZone.UTC).plusSeconds(loginUser.getExpiresIn()));
		jObject.put("refreshToken", loginUser.getRefreshToken());
		return jObject.toString();
	}



	@RequestMapping(value = "/getdistrict", method = RequestMethod.GET)
	public String getDistrictDetails(@RequestParam("searchToken") String searchToken, HttpServletRequest request) throws  ApplicationException {
		return userService.getDistrictDetails(searchToken);
	}
	
}
