package com.adobe.asm.util;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.util.Base64;
import java.util.List;
import java.util.Map;

import javax.net.ssl.SSLContext;

import org.apache.http.HttpHost;
import org.apache.http.NameValuePair;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.config.Registry;
import org.apache.http.config.RegistryBuilder;
import org.apache.http.conn.socket.ConnectionSocketFactory;
import org.apache.http.conn.socket.PlainConnectionSocketFactory;
import org.apache.http.conn.ssl.NoopHostnameVerifier;
import org.apache.http.conn.ssl.SSLConnectionSocketFactory;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.impl.conn.DefaultProxyRoutePlanner;
import org.apache.http.impl.conn.PoolingHttpClientConnectionManager;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.adobe.asm.config.ProxyConfig;
import com.adobe.asm.exceptions.ApplicationException;

@Component
public class HTTPClientUtil {
	private static Logger log = LoggerFactory.getLogger(HTTPClientUtil.class);

	@Autowired
	private ProxyConfig proxyConfig;

	public String executePostRequest(String url, Map<String, String> headerValues, List<NameValuePair> urlParameters)
			throws ApplicationException {

		try {
			return this.httpPost(url, headerValues, urlParameters);
		} catch (Exception e) {
			log.error("Error in executing the post request :  " + e);
			throw new ApplicationException("Error in executing the Request : " + e.getMessage());
		}

	}

	private String httpPost(String url, Map<String, String> headerValues, List<NameValuePair> urlParameters)
			throws ApplicationException, IOException {

		CloseableHttpClient httpClient = null;
		String httpResonse = null;
		try {
			if (proxyConfig.isEnabled()) {
				httpClient = HttpClients.custom().setRoutePlanner(
						new DefaultProxyRoutePlanner(new HttpHost(proxyConfig.getHost(), proxyConfig.getPort())))
						.build();
			} else {
				httpClient = HttpClients.createDefault();
			}

			// Build the http request (with valid header and parameters)
			HttpPost httpPost = new HttpPost(url);

			for (Map.Entry<String, String> entry : headerValues.entrySet()) {
				// Set header
				httpPost.addHeader(entry.getKey(), entry.getValue());
			}

			// Set url parameters
			httpPost.setEntity(new UrlEncodedFormEntity(urlParameters));

			CloseableHttpResponse httpResponse = httpClient.execute(httpPost);
			httpResonse = this.httpResponseReader(httpResponse);

		} catch (Exception e) {
			log.error("Error in executing the post rrequest :  " + e);
			throw new ApplicationException(e.getMessage());
		} finally {
			if (httpClient != null) {
				httpClient.close();
			}
		}

		return httpResonse;
	}

	public String executeGetRequest(String url, Map<String, String> headerValues) throws ApplicationException {

		try {

			return this.httpGet(url, headerValues);

		} catch (Exception e) {
			log.error("Error in executing the get request :  " + e);
			throw new ApplicationException("Error in executing the Request : " + e.getMessage());
		}

	}

	private String httpGet(String url, Map<String, String> headerValues) throws ApplicationException, IOException {

		final SSLConnectionSocketFactory sslsf;

		CloseableHttpClient httpClient = null;
		String httpGetResonse = null;
		try {
			HttpGet httpGet = new HttpGet(url);
			for (Map.Entry<String, String> entry : headerValues.entrySet()) {
				httpGet.addHeader(entry.getKey(), entry.getValue());
			}

			sslsf = new SSLConnectionSocketFactory(SSLContext.getDefault(), NoopHostnameVerifier.INSTANCE);
			final Registry<ConnectionSocketFactory> registry = RegistryBuilder.<ConnectionSocketFactory>create()
					.register(ApplicationConstants.HTTP, new PlainConnectionSocketFactory())
					.register(ApplicationConstants.HTTPS, sslsf).build();

			try (final PoolingHttpClientConnectionManager cm = new PoolingHttpClientConnectionManager(registry)) {
				cm.setMaxTotal(100);
				httpClient = HttpClients.custom().setSSLSocketFactory(sslsf).setConnectionManager(cm).build();
				CloseableHttpResponse httpResponse = httpClient.execute(httpGet);

				httpGetResonse = this.httpResponseReader(httpResponse);

			}

		} catch (Exception e) {
			log.error("Error in executing the get request :  " + e);
			throw new ApplicationException(e.getMessage());
		}
		return httpGetResonse;
	}

	private String httpResponseReader(CloseableHttpResponse httpResponse) throws ApplicationException, IOException {

		if (httpResponse != null) {

			BufferedReader reader = new BufferedReader(
					new InputStreamReader(httpResponse.getEntity().getContent(), ApplicationConstants.CHAR_ENCODING));

			if (httpResponse.getStatusLine().getStatusCode() == 200) {
				String httpData = reader.readLine();
				reader.close();
				return httpData;
			} else {
				throw new ApplicationException("Error in request : " + reader.readLine());
			}
		} else {
			throw new ApplicationException("Error in receiving the response from host server");
		}

	}

	public String encodeSAMLRequest(String samlAssertion) throws UnsupportedEncodingException {

		return Base64.getUrlEncoder().encodeToString(samlAssertion.getBytes(ApplicationConstants.CHAR_ENCODING));
	}

	public String decodeSAMLRequest(String encodedSamlAssertion) throws UnsupportedEncodingException {

		byte[] urlDecodedBytes = Base64.getUrlDecoder().decode(encodedSamlAssertion);

		return new String(urlDecodedBytes, ApplicationConstants.CHAR_ENCODING);
	}

}
