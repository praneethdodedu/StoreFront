package com.adobe.asm.controller;

import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.adobe.asm.constant.model.UserProfile;
import com.adobe.asm.exceptions.ApplicationException;
import com.adobe.asm.model.LoginResponse;
import com.adobe.asm.service.impl.AuthServiceImpl;
import com.adobe.asm.service.impl.SamlAssertServiceImpl;
import com.adobe.asm.service.impl.UserServiceImpl;
import com.adobe.asm.util.ApplicationConstants;
import com.adobe.asm.util.HTTPClientUtil;
import com.mysql.jdbc.StringUtils;

@Controller
public class OAuthController {

	private static Logger log = LoggerFactory.getLogger(OAuthController.class);

	@Autowired
	private AuthServiceImpl authService;

	@Autowired
	private SamlAssertServiceImpl samlService;

	@Autowired
	private UserServiceImpl userService;

	@Autowired
	private HTTPClientUtil httpClientUtil;

	@Value("${com.pearson.k12rs.app.redirect}")
	private String appRedirectURI;

	@RequestMapping("/")
	public ModelAndView welcome(Map<String, Object> model, HttpServletRequest request) {

		Cookie[] cookies = request.getCookies();

		if (cookies != null) {
			for (Cookie cookie : cookies) {
				if ("appPrince".equalsIgnoreCase(cookie.getName())) {
					Map<String, String> oAuthModel = new HashMap<>();

					oAuthModel.put("samlAssertion", null);
					oAuthModel.put("reDirectDest", appRedirectURI);

					return new ModelAndView("redirectCode", oAuthModel);

				}
			}
		}

		return new ModelAndView(ApplicationConstants.LOGIN_PAGE);

	}

	/**
	 * Pending tasks:Code to remove any local sessions , cookies stored for the
	 * user and finally remove the access and refresh token instance from
	 * authenticate server.
	 * 
	 * @return
	 */
	@RequestMapping("/logout")
	public String logout() {

		return ApplicationConstants.LOGIN_PAGE;
	}

	/**
	 * 
	 * Step1: Get the Access token and refresh token Step2: Get User profile by
	 * using access token Step3 : Build Saml Assertion using Access token and
	 * user
	 * 
	 * @param userName
	 * @param password
	 * @param request
	 * @return
	 * @throws ApplicationException
	 */
	@RequestMapping(value = "/loginReq", method = RequestMethod.POST)
	public ModelAndView doLoginReq(@RequestParam("username") String userName, @RequestParam("password") String password,
			@RequestParam("searchbox") String searchBox, HttpServletRequest request) throws ApplicationException {

		LoginResponse loginUser = null;
		UserProfile userProfile;

		Map<String, String> oAuthModel = new HashMap<>();
		try {

			if (!StringUtils.isNullOrEmpty(userName) && !StringUtils.isNullOrEmpty(password)) {
				loginUser = authService.authenticateUser(userName.trim(), password);
				if (loginUser == null) {
					oAuthModel.put(ApplicationConstants.ERROR_MESSAGE, ApplicationConstants.LOGIN_FAILED_ERR_MSG);
					return new ModelAndView(ApplicationConstants.LOGIN_PAGE, oAuthModel);
				}

				userProfile = userService.getUerProfile(loginUser);

				log.info("userProfile: {}", userProfile);

				if (userProfile == null) {
					oAuthModel.put(ApplicationConstants.ERROR_MESSAGE, "User Profile not found");
					return new ModelAndView(ApplicationConstants.LOGIN_PAGE, oAuthModel);
				}

				String assertion = samlService.buildSAMLAssertion(userProfile, loginUser);

				oAuthModel.put("samlAssertion", assertion);
				oAuthModel.put("samlEncodedAssertion", httpClientUtil.encodeSAMLRequest(assertion));
				oAuthModel.put("reDirectDest", appRedirectURI);

				return new ModelAndView("redirectCode", oAuthModel);

			} else {
				throw new ApplicationException(ApplicationConstants.LOGIN_FAILED_ERR_MSG);
			}

		} catch (Exception e) {
			log.error("Error in retrieving refresh token {}", e);
			oAuthModel.put(ApplicationConstants.ERROR_MESSAGE, ApplicationConstants.LOGIN_FAILED_ERR_MSG);
			return new ModelAndView(ApplicationConstants.LOGIN_PAGE, oAuthModel);
		}
	}
}
