/**
 * 
 */
package com.adobe.asm.exceptions;

/**
 * @author Ramsudheer.Palnati
 *
 */
public class ApplicationException extends Exception{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 4987431024629289091L;

	public ApplicationException(String message){
		super(message);
	}

}
